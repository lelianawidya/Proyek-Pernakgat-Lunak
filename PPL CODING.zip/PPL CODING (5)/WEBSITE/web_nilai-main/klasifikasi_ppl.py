import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB

def proses_klasifikasi(df):
    mapel = ['Matematika', 'IPA', 'IPS', 'Bahasa_Indonesia', 'Bahasa_Inggris']

    # hitung rata-rata nilai
    for m in mapel:
        df[m] = df[[f'{m}_UH', f'{m}_UTS', f'{m}_UAS']].mean(axis=1)

    df_prep = df[['Nama_Siswa', 'Jenis_Kelamin'] + mapel]

    # penentuan jurusan awal
    def tentukan_jurusan(row):
        skor = {
            'IPA': (row['Matematika'] + row['IPA'] + row['Bahasa_Inggris']) / 3,
            'IPS': (row['IPS'] + row['Bahasa_Indonesia']) / 2,
            'Akuntansi': (row['Matematika'] + row['IPS']) / 2,
            'Perkantoran': (row['Bahasa_Indonesia'] + row['IPS']) / 2,
            'Multimedia': (row['Bahasa_Inggris'] + row['Matematika']) / 2,
            'TKJ': (row['Matematika'] + row['IPA']) / 2,
            'RPL': (row['Matematika'] + row['Bahasa_Inggris']) / 2
        }
        return max(skor, key=skor.get)

    df_prep['Jurusan_Awal'] = df_prep.apply(tentukan_jurusan, axis=1)

    X = df_prep[mapel]
    y = df_prep['Jurusan_Awal']

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    knn = KNeighborsClassifier(n_neighbors=5)
    knn.fit(X_scaled, y)

    nb = GaussianNB()
    nb.fit(X_scaled, y)

    df_prep['Prediksi_KNN'] = knn.predict(X_scaled)
    df_prep['Prediksi_NaiveBayes'] = nb.predict(X_scaled)

    return df_prep