import pandas as pd
from flask import Flask, render_template, request, send_file
from klasifikasi_ppl import proses_klasifikasi

# =========================
# INISIALISASI FLASK (WAJIB DI ATAS)
# =========================
app = Flask(__name__)

# =========================
# ROUTE HALAMAN AWAL
# =========================
@app.route('/')
def index():
    return render_template('index.html')

# =========================
# ROUTE UPLOAD FILE
# =========================
@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'GET':
        return "Halaman ini hanya untuk proses upload melalui form."

    file = request.files.get('file')

    if not file or file.filename == '':
        return "File belum dipilih"

    filename = file.filename.lower()

    if filename.endswith('.csv'):
        df = pd.read_csv(file)
    elif filename.endswith('.xlsx'):
        df = pd.read_excel(file)
    else:
        return "Format file tidak didukung"

    hasil = proses_klasifikasi(df)

    output_file = 'hasil_klasifikasi.xlsx'
    hasil.to_excel(output_file, index=False)

    return render_template(
        'result.html',
        tables=hasil.to_html(classes='table', index=False),
        file=output_file
    )

# =========================
# ROUTE DOWNLOAD HASIL
# =========================
@app.route('/download')
def download():
    return send_file('hasil_klasifikasi.xlsx', as_attachment=True)

# =========================
# JALANKAN SERVER
# =========================
if __name__ == '__main__':
    app.run(debug=True)
